package com.example.timeplanningassistant

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import kotlin.random.Random

class ActivityRecommendationActivity : AppCompatActivity() {

    private lateinit var activityCardView: CardView
    private lateinit var activityNameTextView: TextView
    private lateinit var activityDescriptionTextView: TextView
    private lateinit var activityImageView: ImageView

    // 更新活动数据，包含多个标签
    private val activities = listOf(
        //标签一：运动健身(室内)
        Activity("瑜伽或冥想", "通过瑜伽拉伸和冥想来放松身心，增强灵活性和内在平静。", R.drawable.wusaqi, "运动健身", "室内", ""), // 无限制参与人数
        Activity("室内跑步机或动感单车", "在家锻炼有氧运动，提升心肺功能，同时燃烧卡路里。", R.drawable.chiikawa1, "运动健身", "室内", ""), // 无限制参与人数
        Activity("举重或阻力训练", "使用哑铃或阻力带进行力量训练，改善肌肉耐力和力量。", R.drawable.chiikawa2, "运动健身", "室内", ""), // 无限制参与人数
        Activity("跳舞课程", "伴随音乐在家跳舞，不仅有趣还能让身体充满活力。", R.drawable.chiikawa3, "运动健身", "室内", ""), // 无限制参与人数
        Activity("高强度间歇训练 (HIIT)", "短时间内进行高强度运动，有效提高代谢率。", R.drawable.chiikawa4, "运动健身", "室内", ""), // 无限制参与人数
        Activity("有氧舞蹈", "跟随在线教程跳有氧舞蹈，锻炼心肺并享受欢快音乐。", R.drawable.chiikawa5, "运动健身", "室内", ""), // 无限制参与人数
        Activity("太极", "练习慢而流畅的太极动作，增强身体平衡和柔韧性。", R.drawable.chiikawa6, "运动健身", "室内", ""), // 无限制参与人数
        Activity("健身环大冒险", "用游戏化的健身设备进行有趣的锻炼，保持活力。", R.drawable.chiikawa7, "运动健身", "室内", ""), // 无限制参与人数
        Activity("体操训练", "学习和练习体操基本动作，如倒立和劈叉。", R.drawable.chiikawa8, "运动健身", "室内", ""), // 无限制参与人数
        Activity("拳击训练", "用拳击手套练习打沙袋，释放压力并锻炼肌肉。", R.drawable.chiikawa9, "运动健身", "室内", ""), // 无限制参与人数
        Activity("普拉提", "用地垫进行普拉提训练，加强核心肌肉并改善体态。", R.drawable.chiikawa10, "运动健身", "室内", ""), // 无限制参与人数
        Activity("跳绳挑战", "尝试每天跳绳一段时间，逐渐提高你的耐力和心肺功能。", R.drawable.chiikawa11, "运动健身", "室内", ""), // 无限制参与人数
        Activity("弹力球健身", "用健身球练习平衡和力量训练，强化肌肉群。", R.drawable.chiikawa13, "运动健身", "室内", ""), // 无限制参与人数
        Activity("滑板模拟", "在家用滑板平衡器练习，提高核心力量和平衡感。", R.drawable.chiikawa14, "运动健身", "室内", ""), // 无限制参与人数
        Activity("模拟攀岩", "用攀岩握把安装在家中，练习手指力量和抓握能力。", R.drawable.chiikawa15, "运动健身", "室内", ""), // 无限制参与人数
        Activity("体能障碍赛", "设置家具和其他物品作为障碍，进行室内体能挑战赛。", R.drawable.chiikawa16, "运动健身", "室内", "多人"), // 多人活动
        Activity("平板支撑挑战", "与家人或朋友一起比谁能坚持平板支撑时间更长。", R.drawable.wusaqi, "运动健身", "室内", "多人"), // 多人活动
        Activity("呼啦圈运动", "用呼啦圈做腰部训练，既有趣又能锻炼腰腹肌群。", R.drawable.chiikawa1, "运动健身", "室内", ""), // 无限制参与人数
        Activity("拉伸与柔韧训练", "专门进行拉伸和柔韧训练，改善身体的柔韧性和灵活性。", R.drawable.chiikawa2, "运动健身", "室内", ""), // 无限制参与人数
        Activity("弹力带锻炼", "用弹力带进行多种肌肉训练，如手臂、腿部和臀部运动。", R.drawable.chiikawa3, "运动健身", "室内", ""), // 无限制参与人数
        Activity("平衡训练", "用平衡板或一条直线进行平衡练习，提升身体稳定性。", R.drawable.chiikawa4, "运动健身", "室内", ""), // 无限制参与人数
        Activity("蹦床训练", "如果空间允许，使用迷你蹦床进行跳跃运动，增强心肺功能。", R.drawable.chiikawa5, "运动健身", "室内", ""), // 无限制参与人数
        Activity("沙袋健身", "用沙袋做深蹲或其他负重练习，提高力量和耐力。", R.drawable.chiikawa6, "运动健身", "室内", ""), // 无限制参与人数
        Activity("手部力量训练", "用握力器或橡皮泥进行手部和前臂肌肉锻炼，增强握力。", R.drawable.chiikawa7, "运动健身", "室内", ""), // 无限制参与人数
        Activity("呼吸控制练习", "做深呼吸和肺活量训练，帮助放松并提升肺功能。", R.drawable.chiikawa8, "运动健身", "室内", ""), // 无限制参与人数
        Activity("模拟单杠锻炼", "用室内单杠或门上引体向上杆练习悬挂和引体向上。", R.drawable.chiikawa9, "运动健身", "室内", ""), // 无限制参与人数
        Activity("蹲墙运动", "背靠墙做蹲墙姿势，锻炼大腿肌肉并挑战耐力。", R.drawable.chiikawa10, "运动健身", "室内", ""), // 无限制参与人数
        Activity("家庭健身巡回赛", "设计一个包含多种运动的健身巡回赛，例如跳跃、俯卧撑、深蹲等。", R.drawable.chiikawa11, "运动健身", "室内", "多人"), // 多人活动
        Activity("足球技巧练习", "用软足球练习控球和花式技巧，提高脚感和灵敏度。", R.drawable.chiikawa13, "运动健身", "室内", "多人"), // 多人活动
        //标签二：休闲游戏(室内)
        Activity("桌游", "邀请家人或朋友一起玩《卡坦岛》或《拼字游戏》，培养策略和沟通能力。", R.drawable.chiikawa14, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("拼图", "挑战自己完成复杂的拼图，提高专注力和观察力。", R.drawable.chiikawa15, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("纸牌游戏", "玩德州扑克或桥牌，锻炼逻辑思维和推理能力。", R.drawable.chiikawa16, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("电子游戏", "在家玩主机或PC游戏，享受沉浸式的虚拟世界探险或竞赛。", R.drawable.wusaqi, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("桌上足球或桌上冰球", "和朋友在家激烈对战，享受团队合作与竞争的乐趣。", R.drawable.chiikawa1, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("拼装模型", "购买并组装模型汽车、飞机或建筑，享受手工制作的乐趣。", R.drawable.chiikawa2, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("飞镖比赛", "设置飞镖靶子，与朋友或家人进行友谊赛。", R.drawable.chiikawa3, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("逃脱游戏", "设计一个室内逃脱游戏，挑战朋友们的解谜能力。", R.drawable.chiikawa4, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("虚拟桌游", "用手机或电脑玩多人虚拟桌游，与远方的朋友互动。", R.drawable.chiikawa5, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("骰子游戏", "玩如《六面骰》、《比大小》等经典的骰子游戏。", R.drawable.chiikawa6, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("单人纸牌游戏", "玩《空当接龙》或《金字塔纸牌》，训练你的思维能力。", R.drawable.chiikawa7, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("迷你高尔夫", "在家设置迷你高尔夫场地，挑战自己和朋友的技巧。", R.drawable.chiikawa8, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("玩套圈游戏", "用不同大小的圈和目标进行套圈比赛，增添趣味。", R.drawable.chiikawa9, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("桌上迷你保龄球", "用微型保龄球套装，开展迷你保龄球比赛。", R.drawable.chiikawa10, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("家庭版夺旗", "设计一个室内版的夺旗游戏，充分利用每个房间。", R.drawable.chiikawa11, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("故事接龙", "和家人一起玩接龙游戏，每人添加一句，创造一个搞笑或奇幻的故事。", R.drawable.chiikawa13, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("谜语比赛", "互相出谜语，看谁能最快猜中答案。", R.drawable.chiikawa14, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("室内飞盘游戏", "使用轻质软飞盘进行室内投掷游戏，锻炼手眼协调能力。", R.drawable.chiikawa15, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("字谜拼图", "制作或购买字谜拼图，挑战你的词汇量和解谜能力。", R.drawable.chiikawa16, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("纸牌塔挑战", "用纸牌建造一座纸牌塔，看谁能建得更高更稳固。", R.drawable.wusaqi, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("室内射箭游戏", "用软头箭和靶子进行室内射箭比赛，提升精确度。", R.drawable.chiikawa1, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("玩纸飞机竞赛", "折纸飞机并进行比赛，看谁的飞机飞得最远或时间最长。", R.drawable.chiikawa2, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("玩跳格子游戏", "用胶带在地板上划跳格子，和家人一起重温童年乐趣。", R.drawable.chiikawa3, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("字母连词游戏", "玩一个字母连词游戏，看看谁能用给定字母组合出最多的词。", R.drawable.chiikawa4, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("室内飞镖", "使用软头飞镖和靶盘，进行飞镖比赛，锻炼专注力。", R.drawable.chiikawa5, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("数字塔拼装", "用积木或数字积木搭建高塔，测试耐心和稳定性。", R.drawable.chiikawa6, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("室内冰壶游戏", "用光滑的瓶盖和布作为道具，模拟冰壶比赛。", R.drawable.chiikawa7, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("数字填字游戏", "做一些数字填字或数独游戏，挑战你的逻辑思维。", R.drawable.chiikawa8, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("家庭打地鼠游戏", "用手工制作简易的打地鼠游戏，进行快速反应挑战。", R.drawable.chiikawa9, "休闲游戏", "室内", "多人"), // 多人活动
        Activity("迷宫制作", "用硬纸板制作一个迷宫，并让弹珠在迷宫中穿越。", R.drawable.chiikawa10, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("制作纸风筝", "手工制作一个纸风筝并装饰，用来装饰你的房间。", R.drawable.chiikawa11, "休闲游戏", "室内", "单人"), // 单人活动
        Activity("室内寻宝游戏", "设计一个寻宝游戏，在家中隐藏线索和宝物，进行大冒险。", R.drawable.chiikawa13, "休闲游戏", "室内", "多人") ,// 多人活动
        //标签三：创意艺术(室内)
        Activity("绘画或素描", "使用油画、丙烯颜料或铅笔绘制作品，表达自己的创造力。", R.drawable.chiikawa14, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("雕刻或陶艺", "使用粘土制作雕塑或实用陶艺器具，感受手工艺的乐趣。", R.drawable.chiikawa15, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("刺绣或编织", "设计并缝制刺绣图案或编织毛衣，创造独一无二的纺织品。", R.drawable.chiikawa16, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("手工制作", "做纸艺、装饰物或DIY卡片，释放创造激情并装饰你的家。", R.drawable.wusaqi, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("手工DIY项目", "进行木工、珠宝设计或模型搭建，享受创造过程中的成就感。", R.drawable.chiikawa1, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("创意毛线画", "用毛线拼贴在画布上，制作有趣的毛线画。", R.drawable.chiikawa2, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("碎纸拼贴画", "撕碎旧杂志和报纸，制作拼贴艺术作品。", R.drawable.chiikawa3, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("玩偶服装设计", "为你的玩偶设计和缝制迷你服装，培养手工艺技能。", R.drawable.chiikawa4, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("个性化明信片", "用彩纸和贴纸制作个性化明信片，寄给朋友和家人。", R.drawable.chiikawa5, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("用塑料瓶做花艺", "用回收的塑料瓶制作手工花艺，提升环保意识。", R.drawable.chiikawa6, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("立体雕塑", "用纸板或泡沫制作立体雕塑，探索结构与设计艺术。", R.drawable.chiikawa7, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("镜面艺术", "在镜子上绘制可擦洗的图案，装饰你的房间并练习艺术技巧。", R.drawable.chiikawa8, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("瓶子装饰", "装饰旧瓶子或玻璃罐，做成家居装饰或花瓶。", R.drawable.chiikawa9, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("贴纸设计", "用剪纸和贴纸材料设计属于你自己的贴纸套装。", R.drawable.chiikawa10, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("装饰灯笼制作", "用纸艺制作装饰灯笼，为家里增添温暖氛围。", R.drawable.chiikawa11, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("丝网印刷", "学习简单的丝网印刷技术，为衣物或布袋印上独特图案。", R.drawable.chiikawa13, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("造纸术", "用废纸和水做成再生手工纸，适合制作卡片或装饰品。", R.drawable.chiikawa14, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("编织手链", "用彩色线或珠子制作手工编织手链，送给朋友作为礼物。", R.drawable.chiikawa15, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("光影摄影", "用手电筒或灯光拍摄光影效果照片，探索摄影创意。", R.drawable.chiikawa16, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("照片拼贴墙", "用家庭照片和装饰品制作一个独特的照片拼贴墙。", R.drawable.wusaqi, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("石头画", "用颜料在石头上绘画，制作可爱的石头宠物或装饰物。", R.drawable.chiikawa1, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("雪花剪纸", "用彩纸剪出各种各样的雪花图案，装饰窗户或房间。", R.drawable.chiikawa2, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("木头雕刻", "用雕刻工具在小木块上雕刻简单的形状或图案，锻炼雕刻技巧。", R.drawable.chiikawa3, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("拼布画", "用废布料拼贴成一幅色彩丰富的拼布画，装饰你的家。", R.drawable.chiikawa4, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("迷你版画制作", "学习简单的版画技术，制作迷你版画作品。", R.drawable.chiikawa5, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("用蜡笔熔画", "用吹风机融化蜡笔，创造独特的抽象艺术画作。", R.drawable.chiikawa6, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("羽毛艺术", "用羽毛制作艺术装饰物，如壁挂或装饰画。", R.drawable.chiikawa7, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("装饰明信片拼贴", "用旧杂志图片和剪贴艺术制作个性化的明信片。", R.drawable.chiikawa8, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("玻璃瓶灯", "用玻璃瓶和LED灯串制作一个装饰灯，为房间增添气氛。", R.drawable.chiikawa9, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("旧书雕刻", "用废旧书本雕刻出精美的3D艺术作品，装饰书架。", R.drawable.chiikawa10, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("水彩画", "用水彩颜料创作柔和而梦幻的画作，探索色彩的流动。", R.drawable.chiikawa11, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("插画设计", "设计插画并为电子书或博客页面制作图像。", R.drawable.chiikawa13, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("手工毛毡制作", "用羊毛毡制作可爱的小动物或饰品，锻炼手艺。", R.drawable.chiikawa14, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("漫画创作", "画出一系列漫画，讲述一个有趣或感人的故事。", R.drawable.chiikawa15, "创意艺术", "室内", ""), // 无限制参与人数
        Activity("拼布艺术", "利用旧衣服制作拼布毯子或装饰垫。", R.drawable.chiikawa16, "创意艺术", "室内", ""), // 无限制参与人数
        //标签四：音乐表演(室内)
        Activity("乐器练习", "学习或提高乐器演奏技巧，如弹吉他、弹钢琴或练习打鼓。", R.drawable.wusaqi, "音乐表演", "室内", "单人"), // 单人活动
        Activity("卡拉OK", "设置家庭卡拉OK设备，邀请朋友或家人一起欢唱，放松身心。", R.drawable.chiikawa1, "音乐表演", "室内", "多人"), // 多人活动
        Activity("即兴戏剧或剧本朗读", "尝试即兴表演或剧本朗读，锻炼你的表演技巧。", R.drawable.chiikawa2, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("唱歌练习或声乐课程", "通过在线课程练习唱歌，提高声乐技巧。", R.drawable.chiikawa3, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("舞蹈排练", "练习新舞步或编舞，为未来的表演或个人乐趣而准备。", R.drawable.chiikawa4, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("录制播客", "与朋友或独自录制播客，分享你的兴趣或讨论热门话题。", R.drawable.chiikawa5, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("制作音乐混音", "用软件混音不同的歌曲，探索你的音乐风格。", R.drawable.chiikawa6, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("乐器合奏", "和家人一起演奏一首合奏曲，享受合作带来的音乐之美。", R.drawable.chiikawa7, "音乐表演", "室内", "多人"), // 多人活动
        Activity("录制翻唱", "翻唱你喜欢的歌曲并录制视频，展示你的才艺。", R.drawable.chiikawa8, "音乐表演", "室内", "单人"), // 单人活动
        Activity("即兴喜剧表演", "进行即兴喜剧表演，挑战自己快速反应和幽默感。", R.drawable.chiikawa9, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("打击乐练习", "用不同的物体做成简易打击乐器，练习节奏感。", R.drawable.chiikawa10, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("影子剧场", "用手影和灯光在墙上表演一个简短的故事，展示你的想象力。", R.drawable.chiikawa11, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("音乐剧欣赏", "在线欣赏经典音乐剧，分析其中的表演和音乐。", R.drawable.chiikawa13, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("原创剧本创作", "写一个短剧，并与家人进行一次小型家庭演出。", R.drawable.chiikawa14, "音乐表演", "室内", "多人"), // 多人活动
        Activity("拍摄短电影", "用手机拍摄并编辑一个微电影，展示你的导演才华。", R.drawable.chiikawa15, "音乐表演", "室内", "多人"), // 多人活动
        Activity("合唱排练", "与家人或朋友一起排练一首合唱曲目，并录制演出视频。", R.drawable.chiikawa16, "音乐表演", "室内", "多人"), // 多人活动
        Activity("即兴声音表演", "用家里的物品制作不同的声音，进行一场即兴音乐会。", R.drawable.wusaqi, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("动画配音", "选一部动画片，给角色配音，发挥你的创意和幽默感。", R.drawable.chiikawa1, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("手偶剧场", "制作手偶，并演出一个有趣或感人的小故事。", R.drawable.chiikawa2, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("现场广播", "模拟一个广播节目，介绍新闻、音乐或故事给家人听。", R.drawable.chiikawa3, "音乐表演", "室内", "多人"), // 多人活动
        Activity("做音乐视频", "为你喜欢的歌曲拍摄一个简单的音乐视频，展示创意编排。", R.drawable.chiikawa4, "音乐表演", "室内", "单人"), // 单人活动
        Activity("学习口技", "模仿不同的声音和节奏，训练你的口技技巧。", R.drawable.chiikawa5, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("指挥练习", "假装自己是指挥家，跟随音乐用手势指挥一支乐队。", R.drawable.chiikawa6, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("戏剧配音练习", "为电影或电视剧场景配音，尝试不同的角色声音。", R.drawable.chiikawa7, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("情景剧编排", "编写一个短剧并与家人合作排演，展示你的剧本创意。", R.drawable.chiikawa8, "音乐表演", "室内", "多人"), // 多人活动
        Activity("学习节奏鼓", "用非正式的鼓或家中的锅碗瓢盆学习节奏打击。", R.drawable.chiikawa9, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("家庭故事夜", "轮流用声音和动作讲述一个家庭故事，展示你的表演才华。", R.drawable.chiikawa10, "音乐表演", "室内", "多人"), // 多人活动
        Activity("即兴舞蹈挑战", "随机播放音乐，进行即兴舞蹈，看谁跳得最有创意。", R.drawable.chiikawa11, "音乐表演", "室内", "多人"), // 多人活动
        Activity("经典电台剧", "重现经典电台剧场景，使用不同的声音和效果讲述故事。", R.drawable.chiikawa13, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("录制个人演讲", "录制一个关于你喜欢话题的演讲，提高你的口才技能。", R.drawable.chiikawa14, "音乐表演", "室内", "单人"), // 单人活动
        Activity("创作主题曲", "为你喜欢的电影、游戏或家庭活动创作一首主题曲。", R.drawable.chiikawa15, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("卡通人物配音", "用不同的声音为卡通人物配音，发挥你的幽默感和声音技巧。", R.drawable.chiikawa16, "音乐表演", "室内", ""), // 无限制参与人数
        Activity("口琴学习", "拿起一把口琴，学习吹奏简单的曲调，体验音乐的乐趣。", R.drawable.wusaqi, "音乐表演", "室内", "单人"), // 单人活动
        Activity("戏剧化演讲", "选择一篇著名的演讲或诗歌，用戏剧化的方式朗诵出来。", R.drawable.chiikawa1, "音乐表演", "室内", ""), // 无限制参与人数
        //标签五：学习教育(室内)
        Activity("学习古代象形文字", "研究古埃及象形文字或玛雅文字，尝试解读和书写。", R.drawable.chiikawa2, "学习教育", "室内", ""), // 无限制参与人数
        Activity("天文观测日志", "记录并研究不同星座和天文现象，跟踪夜空的变化。", R.drawable.chiikawa3, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习基础手语", "掌握一些简单的手语手势，与聋哑人士进行基本沟通。", R.drawable.chiikawa4, "学习教育", "室内", ""), // 无限制参与人数
        Activity("探讨哲学", "选择一个哲学主题，如“幸福的定义”，与家人或朋友展开讨论。", R.drawable.chiikawa5, "学习教育", "室内", ""), // 无限制参与人数
        Activity("昆虫分类", "在网上查找昆虫图鉴，并学习如何辨别和分类不同的昆虫。", R.drawable.chiikawa6, "学习教育", "室内", ""), // 无限制参与人数
        Activity("阅读书籍或电子书", "选择喜欢的小说、非小说或科幻书籍，享受安静的阅读时光。", R.drawable.chiikawa7, "学习教育", "室内", ""), // 无限制参与人数
        Activity("在线学习课程", "通过平台学习新技能或知识，如编程、历史或心理学课程。", R.drawable.chiikawa8, "学习教育", "室内", ""), // 无限制参与人数
        Activity("写作或创作", "尝试写小说、剧本、诗歌或日记，释放你的写作才华。", R.drawable.chiikawa9, "学习教育", "室内", ""), // 无限制参与人数
        Activity("撰写学术论文", "研究并撰写学术论文或专业报告，提升研究与写作能力。", R.drawable.chiikawa10, "学习教育", "室内", ""), // 无限制参与人数
        Activity("语言学习", "用应用程序或书籍学习一门新语言，丰富文化理解与沟通技巧。", R.drawable.chiikawa11, "学习教育", "室内", ""), // 无限制参与人数
        Activity("魔方解谜", "学习如何快速还原魔方，并练习提高速度。", R.drawable.chiikawa13, "学习教育", "室内", ""), // 无限制参与人数
        Activity("做科学实验", "进行家庭安全的科学实验，了解化学或物理原理。", R.drawable.chiikawa14, "学习教育", "室内", ""), // 无限制参与人数
        Activity("心理学入门", "阅读心理学书籍，了解人类行为和心理机制。", R.drawable.chiikawa15, "学习教育", "室内", ""), // 无限制参与人数
        Activity("国际象棋课程", "在线学习国际象棋策略，并与朋友进行虚拟比赛。", R.drawable.chiikawa16, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习鸟类叫声", "研究不同鸟类的叫声，并测试自己是否能认出它们。", R.drawable.wusaqi, "学习教育", "室内", ""), // 无限制参与人数
        Activity("探索天文学", "研究星座和行星，用天文学应用程序了解夜空。", R.drawable.chiikawa1, "学习教育", "室内", ""), // 无限制参与人数
        Activity("编织艺术", "用编织圈和彩色线制作挂毯或装饰品，锻炼手工技巧。", R.drawable.chiikawa2, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习辩论技巧", "与家人进行友好辩论，提升你的逻辑思维和说服能力。", R.drawable.chiikawa3, "学习教育", "室内", "多人"), // 多人活动
        Activity("宇宙探索模拟", "用天文学软件模拟太空旅行，探索太阳系和星座。", R.drawable.chiikawa4, "学习教育", "室内", ""), // 无限制参与人数
        Activity("诗歌创作", "尝试不同的诗歌格式，如十四行诗、自由诗和俳句。", R.drawable.chiikawa5, "学习教育", "室内", ""), // 无限制参与人数
        Activity("自制知识卡片", "制作学习卡片复习不同主题，如历史事件或科学术语。", R.drawable.chiikawa6, "学习教育", "室内", ""), // 无限制参与人数
        Activity("研究微生物", "用显微镜观察简单的微生物，如洋葱表皮细胞或水滴中的生物。", R.drawable.chiikawa7, "学习教育", "室内", ""), // 无限制参与人数
        Activity("编写食谱", "尝试创作你自己的食谱，记录下每个步骤并拍摄食物图片。", R.drawable.chiikawa8, "学习教育", "室内", ""), // 无限制参与人数
        Activity("研究气候变化", "学习气候变化的成因和影响，制定环保计划改变你的生活习惯。", R.drawable.chiikawa9, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习国际象棋开局策略", "学习不同的国际象棋开局，并用它们打败对手。", R.drawable.chiikawa10, "学习教育", "室内", ""), // 无限制参与人数
        Activity("组装机械模型", "购买或自制简单的机械模型，如齿轮装置，学习机械原理。", R.drawable.chiikawa11, "学习教育", "室内", ""), // 无限制参与人数
        Activity("植物图鉴", "研究家中植物的图鉴，学习如何辨识不同的植物种类。", R.drawable.chiikawa13, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习速读", "通过速读练习提高阅读速度和信息处理能力。", R.drawable.chiikawa14, "学习教育", "室内", ""), // 无限制参与人数
        Activity("学习编结", "学习中国传统的编结技巧，如中国结，制作精美的装饰物。", R.drawable.chiikawa15, "学习教育", "室内", ""), // 无限制参与人数
        Activity("烘焙科学", "学习烘焙背后的科学原理，探索不同成分如何影响最终产品。", R.drawable.chiikawa16, "学习教育", "室内", ""), // 无限制参与人数
        Activity("历史角色扮演", "研究一个历史人物，并在家庭中扮演他或她，分享他们的故事。", R.drawable.wusaqi, "学习教育", "室内", ""), // 无限制参与人数
        //标签六：休闲放松(室内)
        Activity("电影或电视剧马拉松", "选一系列电影或剧集，享受一个完全放松的娱乐之夜。", R.drawable.chiikawa1, "休闲放松", "室内", "多人"), // 多人活动
        Activity("听播客或有声书", "选择不同主题的播客，学习新知识或放松心情。", R.drawable.chiikawa2, "休闲放松", "室内", "单人"), // 单人活动
        Activity("烘焙或烹饪新菜肴", "尝试制作复杂的蛋糕或新菜肴，享受厨房中的创作过程。", R.drawable.chiikawa3, "休闲放松", "室内", ""), // 无限制参与人数
        Activity("围绕室内植物进行园艺", "在家布置并养护植物，营造绿意盎然的环境。", R.drawable.chiikawa4, "休闲放松", "室内", ""), // 无限制参与人数
        Activity("水疗日", "给自己做面膜、泡脚或使用精油进行按摩，舒缓压力。", R.drawable.chiikawa5, "休闲放松", "室内", "单人"), // 单人活动
        Activity("弹弹乐玩具制作", "用简单的材料制作弹弹乐玩具，享受轻松的手工活动。", R.drawable.chiikawa6, "休闲放松", "室内", "单人"), // 单人活动
        Activity("DIY手工香袋", "用干花和精油制作香袋，放在衣柜里增添清香。", R.drawable.chiikawa7, "休闲放松", "室内", "单人"), // 单人活动
        Activity("读书笔记整理", "将你喜欢的书籍整理成笔记，并加入插图或标注。", R.drawable.chiikawa8, "休闲放松", "室内", "单人"), // 单人活动
        Activity("微型室内花园", "用小盆栽和多肉植物设计一个微型花园，提升空间美感。", R.drawable.chiikawa9, "休闲放松", "室内", "单人"), // 单人活动
        Activity("温暖脚部按摩", "用按摩器或手动按摩工具，给脚部进行舒缓按摩，放松身心。", R.drawable.chiikawa10, "休闲放松", "室内", "单人"), // 单人活动
        Activity("蜡烛制作", "用天然蜡和精油制作香薰蜡烛，打造温馨的氛围。", R.drawable.chiikawa11, "休闲放松", "室内", "单人"), // 单人活动
        Activity("室内垂钓游戏", "用磁性垂钓玩具和水盆进行模拟钓鱼游戏，增添乐趣。", R.drawable.chiikawa13, "休闲放松", "室内", "单人"), // 单人活动
        Activity("放松按摩", "与伴侣交换肩颈按摩，放松紧张的肌肉。", R.drawable.chiikawa14, "休闲放松", "室内", "多人"), // 多人活动
        Activity("香氛冥想", "使用香薰蜡烛或精油进行冥想，提升专注力与内心平静。", R.drawable.chiikawa15, "休闲放松", "室内", ""), // 无限制参与人数
        Activity("室内帐篷营地", "搭建帐篷，在家体验一次温馨的室内露营。", R.drawable.chiikawa16, "休闲放松", "室内", "多人"), // 多人活动
        Activity("做香草泡浴", "在家享受香草泡澡，舒缓肌肉并释放压力。", R.drawable.wusaqi, "休闲放松", "室内", "单人"), // 单人活动
        Activity("香氛笔记本", "给你的笔记本页添加不同的香味，记录不同心情的笔记。", R.drawable.chiikawa1, "休闲放松", "室内", "单人"), // 单人活动
        Activity("茶道体验", "学习和练习茶道，提升你的感官体验与内心平静。", R.drawable.chiikawa2, "休闲放松", "室内", ""), // 无限制参与人数
        Activity("收听自然音效", "用音效播放大自然的声音，如海浪、鸟鸣，帮助放松。", R.drawable.chiikawa3, "休闲放松", "室内", "单人"), // 单人活动
        Activity("冥想涂色本", "使用涂色本来放松，帮助集中注意力和舒缓焦虑。", R.drawable.chiikawa4, "休闲放松", "室内", "单人"), // 单人活动
        Activity("书籍讨论会", "选择一本书并组织一个小型书籍讨论会，与家人分享观点。", R.drawable.chiikawa5, "休闲放松", "室内", "多人"), // 多人活动
        Activity("温暖手工披肩制作", "学习用针织技巧制作温暖的披肩或围巾。", R.drawable.chiikawa6, "休闲放松", "室内", "单人"), // 单人活动
        Activity("天然护肤品制作", "制作简单的自制护肤品，如蜂蜜面膜或燕麦磨砂膏。", R.drawable.chiikawa7, "休闲放松", "室内", "单人"), // 单人活动
        Activity("感恩日记", "每天写下一件你感恩的事情，帮助提升积极情绪。", R.drawable.chiikawa8, "休闲放松", "室内", "单人"), // 单人活动
        Activity("泡泡浴体验", "放松在一个放满泡泡的浴缸里，点上蜡烛，享受舒适的时光。", R.drawable.chiikawa9, "休闲放松", "室内", "单人"), // 单人活动
        Activity("精油香薰体验", "用不同的精油进行香薰疗法，帮助舒缓压力和放松情绪。", R.drawable.chiikawa10, "休闲放松", "室内", "单人"), // 单人活动
        Activity("制作豆袋暖手袋", "用布料和大米制作一个可以加热的豆袋，用来取暖或舒缓肌肉。", R.drawable.chiikawa11, "休闲放松", "室内", "单人"), // 单人活动
        Activity("抚慰性阅读", "阅读一本温暖治愈的书，帮助内心得到安慰和平静。", R.drawable.chiikawa13, "休闲放松", "室内", "单人"), // 单人活动
        Activity("手工草编", "学习用草绳编织装饰品或篮子，体验自然手工艺。", R.drawable.chiikawa14, "休闲放松", "室内", "单人"), // 单人活动
        Activity("熏香疗法", "用不同的熏香棒或精油，进行一次舒缓的香薰体验。", R.drawable.chiikawa15, "休闲放松", "室内", "单人"), // 单人活动
        Activity("编织地毯", "用旧衣物条编织一个小型地毯，为你的房间增添特色。", R.drawable.chiikawa16, "休闲放松", "室内", "单人"), // 单人活动
        Activity("居家露天野餐", "在客厅铺上野餐毯，准备好食物，进行一次居家露天野餐体验。", R.drawable.wusaqi, "休闲放松", "室内", "多人"), // 多人活动
        Activity("泡泡冥想", "吹泡泡并观察它们，结合深呼吸练习，达到冥想放松效果。", R.drawable.chiikawa1, "休闲放松", "室内", "单人"), // 单人活动
        Activity("DIY梦幻灯串", "用纸艺制作灯罩，装饰灯串，为你的空间增添梦幻氛围。", R.drawable.chiikawa2, "休闲放松", "室内", "单人"), // 单人活动
        //标签七：科技项目(室内)
        Activity("编程或软件开发", "完成编程项目或学习新语言，创建应用程序或网站。", R.drawable.chiikawa3, "科技项目", "室内", ""), // 无限制参与人数
        Activity("机器人或电子工程项目", "搭建简单的机器人或电子装置，激发你的工程热情。", R.drawable.chiikawa4, "科技项目", "室内", ""), // 无限制参与人数
        Activity("3D打印与设计", "设计并打印3D物品，享受数字创作带来的满足感。", R.drawable.chiikawa5, "科技项目", "室内", ""), // 无限制参与人数
        Activity("虚拟现实体验", "使用VR设备体验新世界，探索游戏或虚拟旅行。", R.drawable.chiikawa6, "科技项目", "室内", "单人"), // 单人活动
        Activity("创建数字艺术", "在平板或电脑上创作数字插图、动画或设计项目。", R.drawable.chiikawa7, "科技项目", "室内", ""), // 无限制参与人数
        Activity("制作迷你台风发电机", "用磁铁和铜线制作一个简单的迷你发电机，学习电磁原理。", R.drawable.chiikawa8, "科技项目", "室内", ""), // 无限制参与人数
        Activity("Arduino编程项目", "尝试用Arduino控制简单的电子装置，如LED灯或小型马达。", R.drawable.chiikawa9, "科技项目", "室内", ""), // 无限制参与人数
        Activity("旧电脑改造", "学习如何拆解和改造旧电脑，使其功能更加多样化。", R.drawable.chiikawa10, "科技项目", "室内", ""), // 无限制参与人数
        Activity("数字插画练习", "用平板电脑学习数字插画技巧，绘制出属于你的艺术作品。", R.drawable.chiikawa11, "科技项目", "室内", ""), // 无限制参与人数
        Activity("家庭影院夜", "设置一个迷你影院，播放经典电影并准备零食。", R.drawable.chiikawa13, "科技项目", "室内", "多人"), // 多人活动
        Activity("智能家居改造", "研究如何优化家中的智能设备，提高生活便利性。", R.drawable.chiikawa14, "科技项目", "室内", ""), // 无限制参与人数
        Activity("建立私人博客", "创建并设计自己的博客平台，分享你的生活故事或见解。", R.drawable.chiikawa15, "科技项目", "室内", "单人"), // 单人活动
        Activity("编写一本电子书", "用电子书格式编写一本关于你的兴趣或专业知识的书。", R.drawable.chiikawa16, "科技项目", "室内", ""), // 无限制参与人数
        Activity("学习无人机操作", "在家研究无人机飞行理论，为未来的操作做准备。", R.drawable.wusaqi, "科技项目", "室内", ""), // 无限制参与人数
        Activity("设计家用机器人", "研究如何用简单的机器人套件制作一个家用机器人。", R.drawable.chiikawa1, "科技项目", "室内", ""), // 无限制参与人数
        Activity("学习3D建模", "学习使用3D建模软件，设计家具或装饰品。", R.drawable.chiikawa2, "科技项目", "室内", ""), // 无限制参与人数
        Activity("VR绘画", "如果有VR设备，尝试在虚拟现实中创作艺术作品。", R.drawable.chiikawa3, "科技项目", "室内", "单人"), // 单人活动
        Activity("编程小游戏", "设计并编写一个简单的文字或图形小游戏，与朋友分享。", R.drawable.chiikawa4, "科技项目", "室内", ""), // 无限制参与人数
        Activity("创建家庭数据库", "用软件建立一个家庭物品或收据的数据库，便于管理。", R.drawable.chiikawa5, "科技项目", "室内", ""), // 无限制参与人数
        Activity("手机摄影挑战", "设置一个摄影主题，使用手机拍摄一系列艺术照片。", R.drawable.chiikawa6, "科技项目", "室内", "单人"), // 单人活动
        Activity("家用科技演示", "演示如何优化家用智能设备，创建更智能的生活环境。", R.drawable.chiikawa7, "科技项目", "室内", ""), // 无限制参与人数
        Activity("LED灯光项目", "用LED灯条装饰房间，并编程控制灯光效果。", R.drawable.chiikawa8, "科技项目", "室内", ""), // 无限制参与人数
        Activity("AI工具学习", "学习使用AI绘画或文字生成工具，探索人工智能的创作能力。", R.drawable.chiikawa9, "科技项目", "室内", ""), // 无限制参与人数
        Activity("网络安全课程", "学习如何保护你的数据隐私，了解基本的网络安全措施。", R.drawable.chiikawa10, "科技项目", "室内", ""), // 无限制参与人数
        Activity("虚拟博物馆参观", "在家中在线游览全球著名的博物馆，学习艺术和历史知识。", R.drawable.chiikawa11, "科技项目", "室内", ""), // 无限制参与人数
        Activity("家庭迷你电路实验", "用电路套件设计简单的电路项目，如LED灯亮灭实验。", R.drawable.chiikawa13, "科技项目", "室内", ""), // 无限制参与人数
        Activity("自制小风力发电机", "用风扇、磁铁和铜线制作一个简单的风力发电机。", R.drawable.chiikawa14, "科技项目", "室内", ""), // 无限制参与人数
        Activity("学习图像编辑", "用图像编辑软件学习基础的照片修饰和图像创意。", R.drawable.chiikawa15, "科技项目", "室内", ""), // 无限制参与人数
        Activity("3D拼图模型", "尝试组装一个3D拼图模型，如地球仪或城市地标。", R.drawable.chiikawa16, "科技项目", "室内", ""), // 无限制参与人数
        Activity("自动浇水花盆", "用塑料瓶和绳子制作一个简单的自动浇水系统。", R.drawable.wusaqi, "科技项目", "室内", ""), // 无限制参与人数
        Activity("家庭天气站", "用简单的设备制作一个家庭天气站，记录温度、湿度和气压。", R.drawable.chiikawa1, "科技项目", "室内", ""), // 无限制参与人数
        Activity("学习Python编程", "在线学习Python编程基础，编写简单的小游戏或工具。", R.drawable.chiikawa2, "科技项目", "室内", ""), // 无限制参与人数
        Activity("设计徽标", "用图形设计软件设计一个属于自己的徽标或品牌形象。", R.drawable.chiikawa3, "科技项目", "室内", ""), // 无限制参与人数
        Activity("家庭投影仪DIY", "用透镜和纸箱制作一个简单的家庭投影仪，享受大屏电影。", R.drawable.chiikawa4, "科技项目", "室内", ""), // 无限制参与人数
        //标签一：运动健身(室外)
        Activity("跑步或慢跑", "在公园、街道或操场进行慢跑或快跑，提升体能和心肺功能。", R.drawable.chiikawa5, "运动健身", "室外", ""), // 无限制参与人数
        Activity("户外瑜伽", "在草坪或沙滩上练习瑜伽，呼吸新鲜空气，感受大自然。", R.drawable.chiikawa6, "运动健身", "室外", ""), // 无限制参与人数
        Activity("骑自行车", "骑自行车穿越城市或乡村道路，增强下肢力量和耐力。", R.drawable.chiikawa7, "运动健身", "室外", ""), // 无限制参与人数
        Activity("徒步旅行", "探索自然景区或山间步道，锻炼身体同时亲近自然。", R.drawable.chiikawa8, "运动健身", "室外", ""), // 无限制参与人数
        Activity("攀岩", "进行自然岩壁攀爬或人工攀岩，挑战自我并提升身体协调性。", R.drawable.chiikawa9, "运动健身", "室外", ""), // 无限制参与人数
        Activity("户外跳绳", "利用空旷空间进行跳绳运动，锻炼心肺功能。", R.drawable.chiikawa10, "运动健身", "室外", ""), // 无限制参与人数
        Activity("露天健身器材训练", "使用公园里的健身器材进行力量或平衡训练。", R.drawable.chiikawa11, "运动健身", "室外", ""), // 无限制参与人数
        Activity("滑板或轮滑", "尝试滑板或轮滑，既能锻炼平衡又充满乐趣。", R.drawable.chiikawa13, "运动健身", "室外", ""), // 无限制参与人数
        Activity("足球比赛", "组织朋友或家庭成员参与简单的球类运动。", R.drawable.chiikawa14, "运动健身", "室外", "多人"), // 多人活动
        Activity("篮球比赛", "和朋友一起在球场上打篮球，锻炼你的技巧和体能。", R.drawable.chiikawa15, "运动健身", "室外", "多人"), // 多人活动
        Activity("野外越野跑", "选择自然地形进行越野跑步，提高耐力和挑战性。", R.drawable.chiikawa16, "运动健身", "室外", ""), // 无限制参与人数
        //标签二：休闲游戏(室内)
        Activity("飞盘游戏", "与朋友或宠物在空旷场地玩飞盘，享受互动的乐趣。", R.drawable.wusaqi, "休闲活动", "室外", "多人"), // 多人活动
        Activity("野餐游戏", "结合户外野餐，尝试投掷游戏或简单的户外谜题。", R.drawable.chiikawa1, "休闲活动", "室外", "多人"), // 多人活动
        Activity("真人CS或激光战", "在森林或户外竞技场模拟军事战斗，体验团队合作。", R.drawable.chiikawa2, "休闲活动", "室外", "多人"), // 多人活动
        Activity("放风筝", "在风大的日子放风筝，感受童趣与放松。", R.drawable.chiikawa3, "休闲活动", "室外", ""), // 无限制参与人数
        Activity("捉迷藏", "在树林或公园里玩捉迷藏，适合家庭和朋友一起参与。", R.drawable.chiikawa4, "休闲活动", "室外", "多人"), // 多人活动
        Activity("迷宫挑战", "在农田或特殊迷宫场地里探险，找到正确路径。", R.drawable.chiikawa5, "休闲活动", "室外", ""), // 无限制参与人数
        Activity("真人版飞行棋", "在草地上用巨型道具模拟飞行棋游戏。", R.drawable.chiikawa6, "休闲活动", "室外", "多人"), // 多人活动
        Activity("沙滩排球", "在沙滩上组织排球比赛，感受阳光与汗水的魅力。", R.drawable.chiikawa7, "休闲活动", "室外", "多人"), // 多人活动
        Activity("冒险寻宝", "在指定的区域内设计寻宝路线，结合谜题和地图寻找宝藏。", R.drawable.chiikawa8, "休闲活动", "室外", "多人"), // 多人活动
        Activity("水上活动", "在湖泊或河流中划船、玩水枪或体验漂流。", R.drawable.chiikawa9, "休闲活动", "室外", "多人"), // 多人活动
        //标签三：创意艺术(室内)
        Activity("风景写生", "带上画板和颜料，在户外绘制自然风光或街头景象。", R.drawable.chiikawa10, "创意艺术", "室外", ""),
        Activity("沙滩雕塑", "在沙滩上用沙子和水制作城堡或艺术作品。", R.drawable.chiikawa11, "创意艺术", "室外", ""),
        Activity("自然摄影", "用相机或手机记录独特的自然风景或动物瞬间。", R.drawable.chiikawa13, "创意艺术", "室外", ""),
        Activity("户外壁画创作", "参与社区组织的墙面绘画活动，为公共场地增添色彩。", R.drawable.chiikawa14, "创意艺术", "室外", ""),
        Activity("自然工艺品制作", "收集树叶、松果等自然材料制作装饰品。", R.drawable.chiikawa15, "创意艺术", "室外", ""),
        Activity("石头彩绘", "捡拾平滑的石头，在上面进行彩绘，创作个性作品。", R.drawable.chiikawa16, "创意艺术", "室外", ""),
        Activity("地面粉笔画", "用彩色粉笔在地面画画，适合儿童或街头艺术爱好者。", R.drawable.wusaqi, "创意艺术", "室外", ""),
        Activity("竹子艺术", "用竹子和绳子搭建小型雕塑或实用工具。", R.drawable.chiikawa1, "创意艺术", "室外", ""),
        Activity("草编手工", "学习用野草编织草帽或小型装饰品。", R.drawable.chiikawa2, "创意艺术", "室外", ""),
        Activity("野外音乐会", "携带乐器，与朋友在户外表演或练习音乐。", R.drawable.chiikawa3, "创意艺术", "室外", "多人"),
        //标签四：音乐表演(室内)
        Activity("露天音乐会", "组织或参与户外音乐会，带上乐器或音响，和朋友一起演奏。", R.drawable.chiikawa4, "音乐表演", "室外", "多人"),
        Activity("街头表演", "选择热闹的街区进行音乐或歌唱表演，与路人互动。", R.drawable.chiikawa5, "音乐表演", "室外", ""),
        Activity("吉他弹唱", "在沙滩、公园或草地上自弹自唱，享受音乐带来的惬意时光。", R.drawable.chiikawa6, "音乐表演", "室外", ""),
        Activity("户外合唱", "与朋友组成合唱团，在开放的环境中演唱喜欢的曲目。", R.drawable.chiikawa7, "音乐表演", "室外", "多人"),
        Activity("非洲鼓即兴表演", "在户外用非洲鼓进行节奏练习和即兴演奏，吸引观众参与。", R.drawable.chiikawa8, "音乐表演", "室外", ""),
        Activity("民谣分享会", "邀请朋友在草地上演奏民谣，分享不同的音乐风格。", R.drawable.chiikawa9, "音乐表演", "室外", "多人"),
        Activity("露天录音", "利用自然环境录制音乐或声效，比如鸟鸣、溪水声等，与音乐融合。", R.drawable.chiikawa10, "音乐表演", "室外", ""),
        Activity("手风琴表演", "在社区或公园用手风琴表演传统音乐，让人感受到怀旧的氛围。", R.drawable.chiikawa11, "音乐表演", "室外", ""),
        Activity("打击乐工作坊", "带上小型打击乐器，与参与者一起感受节奏的魅力。", R.drawable.chiikawa13, "音乐表演", "室外", ""),
        Activity("音乐接龙游戏", "两人或多人用乐器接龙演奏旋律，创造出即兴音乐作品。", R.drawable.chiikawa14, "音乐表演", "室外", "多人"),
        //标签五：学习教育(室外)
        Activity("观鸟", "带上望远镜和笔记本，观察记录不同种类的鸟类。", R.drawable.chiikawa15, "学习教育", "室外", ""),
        Activity("植物辨识", "学习认识各种植物和树木，包括它们的特性与用途。", R.drawable.chiikawa16, "学习教育", "室外", ""),
        Activity("天文观测", "在夜间观星，寻找星座或用望远镜观测月球与行星。", R.drawable.wusaqi, "学习教育", "室外", ""),
        Activity("户外科学实验", "在空旷的地方做简单的化学或物理实验，比如水火箭发射。", R.drawable.chiikawa1, "学习教育", "室外", ""),
        Activity("参观历史遗址", "访问当地的历史古迹或文化景点，了解它们的背景故事。", R.drawable.chiikawa2, "学习教育", "室外", ""),
        Activity("野外求生课程", "学习搭帐篷、生火、取水等基本的生存技能。", R.drawable.chiikawa3, "学习教育", "室外", ""),
        Activity("环保教育活动", "参加植树或垃圾清理活动，为自然环境做贡献。", R.drawable.chiikawa4, "学习教育", "室外", ""),
        Activity("昆虫研究", "用网捕捉昆虫，观察其特性并分类记录。", R.drawable.chiikawa5, "学习教育", "室外", ""),
        Activity("拓展训练", "参加户外拓展项目，提升团队合作和个人挑战能力。", R.drawable.chiikawa6, "学习教育", "室外", ""),
        Activity("考古模拟", "在沙地挖掘埋藏物，体验考古学家的乐趣。", R.drawable.chiikawa7, "学习教育", "室外", ""),
        //标签六：休闲放松(室外)
        Activity("户外咖啡时光", "带上便携咖啡壶，在阳光下享受一杯自制咖啡。", R.drawable.chiikawa8, "休闲放松", "室外", ""),
        Activity("吊床放松", "在两棵树间挂上吊床，静静地躺着读书或睡觉。", R.drawable.chiikawa9, "休闲放松", "室外", "单人"),
        Activity("森林浴", "漫步在森林中，放松身心，感受树木带来的宁静。", R.drawable.chiikawa10, "休闲放松", "室外", ""),
        Activity("沙滩晒日光浴", "在沙滩上晒太阳，补充维生素D，放松身心。", R.drawable.chiikawa11, "休闲放松", "室外", ""),
        Activity("溪流泡脚", "在清凉的小溪中泡脚，感受自然水流的按摩。", R.drawable.chiikawa13, "休闲放松", "室外", ""),
        Activity("观日落或日出", "寻找一个最佳观景点，欣赏日落或日出的美景。", R.drawable.chiikawa14, "休闲放松", "室外", ""),
        Activity("野外露天电影", "在户外放映一部经典电影，与家人或朋友共享。", R.drawable.chiikawa15, "休闲放松", "室外", "多人"),
        Activity("自然冥想", "在风景优美的地方进行冥想，感受与自然的连接。", R.drawable.chiikawa16, "休闲放松", "室外", "单人"),
        Activity("野外写作", "带上笔记本，在自然环境中写作灵感随笔。", R.drawable.wusaqi, "休闲放松", "室外", ""),
        Activity("垂钓", "选择安静的湖泊或河流享受钓鱼的乐趣和放松时光。", R.drawable.chiikawa1, "休闲放松", "室外", ""),
        //标签七：科技项目(室外)
        Activity("无人机飞行", "学习操控无人机，拍摄高质量的空中影像。", R.drawable.chiikawa2, "科技项目", "室外", ""),
        Activity("太阳能实验", "设计和测试利用太阳能的装置，比如太阳能灶。", R.drawable.chiikawa3, "科技项目", "室外", ""),
        Activity("遥控车竞赛", "在平坦的草地或沙地上进行遥控车比赛。", R.drawable.chiikawa4, "科技项目", "室外", "多人"),
        Activity("风力发电机模型测试", "用风能设备在户外进行能量转换实验。", R.drawable.chiikawa5, "科技项目", "室外", ""),
        Activity("家庭天文台搭建", "搭建便携式天文观测设备，进行夜晚观察。", R.drawable.chiikawa6, "科技项目", "室外", "多人"),
        Activity("无线电通讯实验", "在户外学习基础无线电通讯技能。", R.drawable.chiikawa7, "科技项目", "室外", ""),
        Activity("风筝装置改造", "制作或改良风筝，尝试实现独特设计的飞行模式。", R.drawable.chiikawa8, "科技项目", "室外", ""),
        Activity("户外机器人挑战", "带上机器人套件，在不同地形上测试功能。", R.drawable.chiikawa9, "科技项目", "室外", ""),
        Activity("天气监测装置", "安装和观察便携式气象监测工具，记录天气数据。", R.drawable.chiikawa10, "科技项目", "室外", ""),
        Activity("自然能量捕获实验", "利用自然环境收集数据，比如水能或风能实验。", R.drawable.chiikawa11, "科技项目", "室外", "")
    )

    private var lastRecommendedActivity: Activity? = null // 用于存储上一次推荐的活动

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activity_recommendation)

        activityCardView = findViewById(R.id.activityCardView)
        activityNameTextView = findViewById(R.id.activityName)
        activityDescriptionTextView = findViewById(R.id.activityDescription)
        activityImageView = findViewById(R.id.activityImage)

        // 获取选中的标签
        val selectedTags = intent.getStringArrayListExtra("selectedTags") ?: arrayListOf()

        if (selectedTags.isNotEmpty()) {
            recommendActivity(selectedTags)
        } else {
            recommendRandomActivity() // 随机推荐活动
        }

        val continueButton: Button = findViewById(R.id.continueButton)
        val homeButton: Button = findViewById(R.id.homeButton)

        continueButton.setOnClickListener {
            recommendActivity(selectedTags)
        }

        homeButton.setOnClickListener {
            finish() // 关闭此活动返回到上一个活动（标签选择页面）
        }

        // 点击活动卡片跳转到活动详情页面(未实现)
        /*activityCardView.setOnClickListener {
            val intent = Intent(this, ActivityDetailActivity::class.java)
            intent.putExtra("activityName", activityNameTextView.text.toString())
            startActivity(intent)
        }*/
    }

    private fun recommendActivity(tags: ArrayList<String>) {
        // 按选择的环境进行筛选
        val environmentSelected = when {
            tags.contains("室内") && tags.contains("室外") -> activities // 两者都选，则可推荐
            tags.contains("室内") -> activities.filter { it.environment == "室内" || it.environment.isEmpty() }
            tags.contains("室外") -> activities.filter { it.environment == "室外" || it.environment.isEmpty() }
            else -> activities // 默认返回未过滤的
        }

        // 按选择的活动类型进行筛选
        var activitiesByType = environmentSelected.filter { activity ->
            tags.contains(activity.type)
        }

        // 按选择的参与人数进行筛选
        var participantsCheck = when {
            tags.contains("个人") && tags.contains("多人") -> activitiesByType // 两者都选，则可推荐
            tags.contains("个人") -> activitiesByType.filter { it.participants == "单人" || it.participants.isEmpty() }
            tags.contains("多人") -> activitiesByType.filter { it.participants == "多人" || it.participants.isEmpty() }
            else -> activitiesByType // 默认返回未过滤的
        }.filter { activity ->
            activity != lastRecommendedActivity // 确保不推荐上一个活动
        }

        // 如果找不到符合条件的活动，最终 fallback 到所有活动
        if (participantsCheck.isEmpty()) {
            participantsCheck = activities.filter { it != lastRecommendedActivity } // 不推荐上一个活动
        }

        // 随机推荐一个活动
        if (participantsCheck.isNotEmpty()) {
            val activity = participantsCheck[Random.nextInt(participantsCheck.size)]
            setupActivityCard(activity)
            lastRecommendedActivity = activity // 更新为当前推荐的活动
        } else {
            activityNameTextView.text = "没有找到活动。"
            activityDescriptionTextView.text = ""
            activityImageView.setImageResource(0) // 清除图片
        }
    }

    private fun recommendRandomActivity() {
        val allActivities = activities.filter { it != lastRecommendedActivity } // 不推荐上一个活动
        if (allActivities.isNotEmpty()) {
            val randomActivity = allActivities[Random.nextInt(allActivities.size)]
            setupActivityCard(randomActivity)
            lastRecommendedActivity = randomActivity // 更新为当前推荐的活动
        }
    }

    private fun setupActivityCard(activity: Activity) {
        activityNameTextView.text = activity.name
        activityDescriptionTextView.text = activity.description
        activityImageView.setImageResource(activity.imageResId)

        when (activity.type) {
            "运动健身" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.sports)
            "休闲游戏" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.game)
            "创意艺术" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.art)
            "音乐表演" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.music)
            "学习教育" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.study)
            "休闲放松" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.relax)
            "科技项目" -> findViewById<RelativeLayout>(R.id.page).setBackgroundResource(R.drawable.tec)
        }
    }

    data class Activity(
        val name: String,
        val description: String,
        val imageResId: Int,
        val type: String,
        val environment: String,
        val participants: String
    )
}


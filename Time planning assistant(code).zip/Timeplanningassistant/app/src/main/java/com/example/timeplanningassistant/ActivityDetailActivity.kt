package com.example.timeplanningassistant

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ActivityDetailActivity : AppCompatActivity() {

    private lateinit var activityDetailTitle: TextView
    private lateinit var activityDetailImage: ImageView
    private lateinit var activityDetailDescription: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        activityDetailTitle = findViewById(R.id.activityDetailTitle)
        activityDetailImage = findViewById(R.id.activityDetailImage)
        activityDetailDescription = findViewById(R.id.activityDetailDescription)

        val activityName = intent.getStringExtra("activityName")
        activityDetailTitle.text = activityName

        // 根据活动名称设置详细信息
        when (activityName) {
            //标签一
            "瑜伽或冥想" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "通过瑜伽拉伸和冥想来放松身心，增强灵活性和内在平静。"
            }
            "室内跑步机或动感单车" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "在家锻炼有氧运动，提升心肺功能，同时燃烧卡路里。"
            }
            "举重或阻力训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "使用哑铃或阻力带进行力量训练，改善肌肉耐力和力量。"
            }
            "跳舞课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "伴随音乐在家跳舞，不仅有趣还能让身体充满活力。"
            }
            "高强度间歇训练 (HIIT)" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "短时间内进行高强度运动，有效提高代谢率。"
            }
            "有氧舞蹈" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "跟随在线教程跳有氧舞蹈，锻炼心肺并享受欢快音乐。"
            }
            "太极" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "练习慢而流畅的太极动作，增强身体平衡和柔韧性。"
            }
            "健身环大冒险" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用游戏化的健身设备进行有趣的锻炼，保持活力。"
            }
            "体操训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "学习和练习体操基本动作，如倒立和劈叉。"
            }
            "拳击训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用拳击手套练习打沙袋，释放压力并锻炼肌肉。"
            }
            "普拉提" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用地垫进行普拉提训练，加强核心肌肉并改善体态。"
            }
            "跳绳挑战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "尝试每天跳绳一段时间，逐渐提高你的耐力和心肺功能。"
            }
            "弹力球健身" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "用健身球练习平衡和力量训练，强化肌肉群。"
            }
            "滑板模拟" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "在家用滑板平衡器练习，提高核心力量和平衡感。"
            }
            "模拟攀岩" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "用攀岩握把安装在家中，练习手指力量和抓握能力。"
            }
            "体能障碍赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "设置家具和其他物品作为障碍，进行室内体能挑战赛。"
            }
            "平板支撑挑战" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "与家人或朋友一起比谁能坚持平板支撑时间更长。"
            }
            "呼啦圈运动" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "用呼啦圈做腰部训练，既有趣又能锻炼腰腹肌群。"
            }
            "拉伸与柔韧训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "专门进行拉伸和柔韧训练，改善身体的柔韧性和灵活性。"
            }
            "弹力带锻炼" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "用弹力带进行多种肌肉训练，如手臂、腿部和臀部运动。"
            }
            "平衡训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "用平衡板或一条直线进行平衡练习，提升身体稳定性。"
            }
            "蹦床训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "如果空间允许，使用迷你蹦床进行跳跃运动，增强心肺功能。"
            }
            "沙袋健身" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用沙袋做深蹲或其他负重练习，提高力量和耐力。"
            }
            "手部力量训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用握力器或橡皮泥进行手部和前臂肌肉锻炼，增强握力。"
            }
            "呼吸控制练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "做深呼吸和肺活量训练，帮助放松并提升肺功能。"
            }
            "模拟单杠锻炼" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用室内单杠或门上引体向上杆练习悬挂和引体向上。"
            }
            "蹲墙运动" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "背靠墙做蹲墙姿势，锻炼大腿肌肉并挑战耐力。"
            }
            "家庭健身巡回赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "设计一个包含多种运动的健身巡回赛，例如跳跃、俯卧撑、深蹲等。"
            }
            "足球技巧练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "用软足球练习控球和花式技巧，提高脚感和灵敏度。"
            }
            //标签二
            "桌游" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "邀请家人或朋友一起玩《卡坦岛》或《拼字游戏》，培养策略和沟通能力。"
            }
            "拼图" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "挑战自己完成复杂的拼图，提高专注力和观察力。"
            }
            "纸牌游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "玩德州扑克或桥牌，锻炼逻辑思维和推理能力。"
            }
            "电子游戏" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "在家玩主机或PC游戏，享受沉浸式的虚拟世界探险或竞赛。"
            }
            "桌上足球或桌上冰球" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "和朋友在家激烈对战，享受团队合作与竞争的乐趣。"
            }
            "拼装模型" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "购买并组装模型汽车、飞机或建筑，享受手工制作的乐趣。"
            }
            "飞镖比赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "设置飞镖靶子，与朋友或家人进行友谊赛。"
            }
            "逃脱游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "设计一个室内逃脱游戏，挑战朋友们的解谜能力。"
            }
            "虚拟桌游" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "用手机或电脑玩多人虚拟桌游，与远方的朋友互动。"
            }
            "骰子游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "玩如《六面骰》、《比大小》等经典的骰子游戏。"
            }
            "单人纸牌游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "玩《空当接龙》或《金字塔纸牌》，训练你的思维能力。"
            }
            "迷你高尔夫" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "在家设置迷你高尔夫场地，挑战自己和朋友的技巧。"
            }
            "玩套圈游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用不同大小的圈和目标进行套圈比赛，增添趣味。"
            }
            "桌上迷你保龄球" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用微型保龄球套装，开展迷你保龄球比赛。"
            }
            "家庭版夺旗" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "设计一个室内版的夺旗游戏，充分利用每个房间。"
            }
            "故事接龙" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "和家人一起玩接龙游戏，每人添加一句，创造一个搞笑或奇幻的故事。"
            }
            "谜语比赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "互相出谜语，看谁能最快猜中答案。"
            }
            "室内飞盘游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "使用轻质软飞盘进行室内投掷游戏，锻炼手眼协调能力。"
            }
            "字谜拼图" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "制作或购买字谜拼图，挑战你的词汇量和解谜能力。"
            }
            "纸牌塔挑战" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "用纸牌建造一座纸牌塔，看谁能建得更高更稳固。"
            }
            "室内射箭游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "用软头箭和靶子进行室内射箭比赛，提升精确度。"
            }
            "玩纸飞机竞赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "折纸飞机并进行比赛，看谁的飞机飞得最远或时间最长。"
            }
            "玩跳格子游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "用胶带在地板上划跳格子，和家人一起重温童年乐趣。"
            }
            "字母连词游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "玩一个字母连词游戏，看看谁能用给定字母组合出最多的词。"
            }
            "室内飞镖" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "使用软头飞镖和靶盘，进行飞镖比赛，锻炼专注力。"
            }
            "数字塔拼装" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用积木或数字积木搭建高塔，测试耐心和稳定性。"
            }
            "室内冰壶游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用光滑的瓶盖和布作为道具，模拟冰壶比赛。"
            }
            "数字填字游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "做一些数字填字或数独游戏，挑战你的逻辑思维。"
            }
            "家庭打地鼠游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用手工制作简易的打地鼠游戏，进行快速反应挑战。"
            }
            "迷宫制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用硬纸板制作一个迷宫，并让弹珠在迷宫中穿越。"
            }
            "制作纸风筝" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "手工制作一个纸风筝并装饰，用来装饰你的房间。"
            }
            "室内寻宝游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "设计一个寻宝游戏，在家中隐藏线索和宝物，进行大冒险。"
            }
            //标签三
            "绘画或素描" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "使用油画、丙烯颜料或铅笔绘制作品，表达自己的创造力。"
            }
            "雕刻或陶艺" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "使用粘土制作雕塑或实用陶艺器具，感受手工艺的乐趣。"
            }
            "刺绣或编织" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "设计并缝制刺绣图案或编织毛衣，创造独一无二的纺织品。"
            }
            "手工制作" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "做纸艺、装饰物或DIY卡片，释放创造激情并装饰你的家。"
            }
            "手工DIY项目" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "进行木工、珠宝设计或模型搭建，享受创造过程中的成就感。"
            }
            "创意毛线画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "用毛线拼贴在画布上，制作有趣的毛线画。"
            }
            "碎纸拼贴画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "撕碎旧杂志和报纸，制作拼贴艺术作品。"
            }
            "玩偶服装设计" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "为你的玩偶设计和缝制迷你服装，培养手工艺技能。"
            }
            "个性化明信片" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "用彩纸和贴纸制作个性化明信片，寄给朋友和家人。"
            }
            "用塑料瓶做花艺" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用回收的塑料瓶制作手工花艺，提升环保意识。"
            }
            "立体雕塑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用纸板或泡沫制作立体雕塑，探索结构与设计艺术。"
            }
            "镜面艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "在镜子上绘制可擦洗的图案，装饰你的房间并练习艺术技巧。"
            }
            "瓶子装饰" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "装饰旧瓶子或玻璃罐，做成家居装饰或花瓶。"
            }
            "贴纸设计" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用剪纸和贴纸材料设计属于你自己的贴纸套装。"
            }
            "装饰灯笼制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用纸艺制作装饰灯笼，为家里增添温暖氛围。"
            }
            "丝网印刷" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "学习简单的丝网印刷技术，为衣物或布袋印上独特图案。"
            }
            "造纸术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "用废纸和水做成再生手工纸，适合制作卡片或装饰品。"
            }
            "编织手链" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "用彩色线或珠子制作手工编织手链，送给朋友作为礼物。"
            }
            "光影摄影" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "用手电筒或灯光拍摄光影效果照片，探索摄影创意。"
            }
            "照片拼贴墙" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "用家庭照片和装饰品制作一个独特的照片拼贴墙。"
            }
            "石头画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "用颜料在石头上绘画，制作可爱的石头宠物或装饰物。"
            }
            "雪花剪纸" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "用彩纸剪出各种各样的雪花图案，装饰窗户或房间。"
            }
            "木头雕刻" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "用雕刻工具在小木块上雕刻简单的形状或图案，锻炼雕刻技巧。"
            }
            "拼布画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "用废布料拼贴成一幅色彩丰富的拼布画，装饰你的家。"
            }
            "迷你版画制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "学习简单的版画技术，制作迷你版画作品。"
            }
            "用蜡笔熔画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用吹风机融化蜡笔，创造独特的抽象艺术画作。"
            }
            "羽毛艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用羽毛制作艺术装饰物，如壁挂或装饰画。"
            }
            "装饰明信片拼贴" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "用旧杂志图片和剪贴艺术制作个性化的明信片。"
            }
            "玻璃瓶灯" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用玻璃瓶和LED灯串制作一个装饰灯，为房间增添气氛。"
            }
            "旧书雕刻" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用废旧书本雕刻出精美的3D艺术作品，装饰书架。"
            }
            "水彩画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用水彩颜料创作柔和而梦幻的画作，探索色彩的流动。"
            }
            "插画设计" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "设计插画并为电子书或博客页面制作图像。"
            }
            "手工毛毡制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "用羊毛毡制作可爱的小动物或饰品，锻炼手艺。"
            }
            "漫画创作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "画出一系列漫画，讲述一个有趣或感人的故事。"
            }
            "拼布艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "利用旧衣服制作拼布毯子或装饰垫。"
            }
            //标签四：音乐表演
            "乐器练习" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "学习或提高乐器演奏技巧，如弹吉他、弹钢琴或练习打鼓。"
            }
            "卡拉OK" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "尝试即兴表演或剧本朗读，锻炼你的表演技巧。"
            }
            "即兴戏剧或剧本朗读" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "利用旧衣服制作拼布毯子或装饰垫。"
            }
            "唱歌练习或声乐课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "通过在线课程练习唱歌，提高声乐技巧。"
            }
            "舞蹈排练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "练习新舞步或编舞，为未来的表演或个人乐趣而准备。"
            }
            "录制播客" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "与朋友或独自录制播客，分享你的兴趣或讨论热门话题。"
            }
            "制作音乐混音" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用软件混音不同的歌曲，探索你的音乐风格。"
            }
            "乐器合奏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "和家人一起演奏一首合奏曲，享受合作带来的音乐之美。"
            }
            "录制翻唱" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "翻唱你喜欢的歌曲并录制视频，展示你的才艺。"
            }
            "即兴喜剧表演" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "进行即兴喜剧表演，挑战自己快速反应和幽默感。"
            }
            "打击乐练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用不同的物体做成简易打击乐器，练习节奏感。"
            }
            "影子剧场" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用手影和灯光在墙上表演一个简短的故事，展示你的想象力。"
            }
            "音乐剧欣赏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "在线欣赏经典音乐剧，分析其中的表演和音乐。"
            }
            "原创剧本创作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "写一个短剧，并与家人进行一次小型家庭演出。"
            }
            "拍摄短电影" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "用手机拍摄并编辑一个微电影，展示你的导演才华。"
            }
            "合唱排练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "与家人或朋友一起排练一首合唱曲目，并录制演出视频。"
            }
            "即兴声音表演" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "用家里的物品制作不同的声音，进行一场即兴音乐会。"
            }
            "动画配音" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "选一部动画片，给角色配音，发挥你的创意和幽默感。"
            }
            "手偶剧场" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "制作手偶，并演出一个有趣或感人的小故事。"
            }
            "现场广播" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "模拟一个广播节目，介绍新闻、音乐或故事给家人听。"
            }
            "做音乐视频" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "为你喜欢的歌曲拍摄一个简单的音乐视频，展示创意编排。"
            }
            "学习口技" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "模仿不同的声音和节奏，训练你的口技技巧。"
            }
            "指挥练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "假装自己是指挥家，跟随音乐用手势指挥一支乐队。"
            }
            "戏剧配音练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "为电影或电视剧场景配音，尝试不同的角色声音。"
            }
            "情景剧编排" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "编写一个短剧并与家人合作排演，展示你的剧本创意。"
            }
            "学习节奏鼓" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用非正式的鼓或家中的锅碗瓢盆学习节奏打击。"
            }
            "家庭故事夜" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "轮流用声音和动作讲述一个家庭故事，展示你的表演才华。"
            }
            "即兴舞蹈挑战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "随机播放音乐，进行即兴舞蹈，看谁跳得最有创意。"
            }
            "经典电台剧" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "重现经典电台剧场景，使用不同的声音和效果讲述故事。"
            }
            "录制个人演讲" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "录制一个关于你喜欢话题的演讲，提高你的口才技能。"
            }
            "创作主题曲" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "为你喜欢的电影、游戏或家庭活动创作一首主题曲。"
            }
            "卡通人物配音" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "用不同的声音为卡通人物配音，发挥你的幽默感和声音技巧。"
            }
            "口琴学习" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "拿起一把口琴，学习吹奏简单的曲调，体验音乐的乐趣。"
            }
            "戏剧化演讲" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "选择一篇著名的演讲或诗歌，用戏剧化的方式朗诵出来。"
            }
            //标签五
            "学习古代象形文字" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "研究古埃及象形文字或玛雅文字，尝试解读和书写。"
            }
            "天文观测日志" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "记录并研究不同星座和天文现象，跟踪夜空的变化。"
            }
            "学习基础手语" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "掌握一些简单的手语手势，与聋哑人士进行基本沟通。"
            }
            "探讨哲学" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "选择一个哲学主题，如“幸福的定义”，与家人或朋友展开讨论。"
            }
            "昆虫分类" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "在网上查找昆虫图鉴，并学习如何辨别和分类不同的昆虫。"
            }
            "阅读书籍或电子书" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "选择喜欢的小说、非小说或科幻书籍，享受安静的阅读时光。"
            }
            "在线学习课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "通过平台学习新技能或知识，如编程、历史或心理学课程。"
            }
            "写作或创作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "尝试写小说、剧本、诗歌或日记，释放你的写作才华。"
            }
            "撰写学术论文" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "研究并撰写学术论文或专业报告，提升研究与写作能力。"
            }
            "语言学习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用应用程序或书籍学习一门新语言，丰富文化理解与沟通技巧。"
            }
            "魔方解谜" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "学习如何快速还原魔方，并练习提高速度。"
            }
            "做科学实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "进行家庭安全的科学实验，了解化学或物理原理。"
            }
            "心理学入门" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "阅读心理学书籍，了解人类行为和心理机制。"
            }
            "国际象棋课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "在线学习国际象棋策略，并与朋友进行虚拟比赛。"
            }
            "学习鸟类叫声" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "研究不同鸟类的叫声，并测试自己是否能认出它们。"
            }
            "探索天文学" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "研究星座和行星，用天文学应用程序了解夜空。"
            }
            "编织艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "用编织圈和彩色线制作挂毯或装饰品，锻炼手工技巧。"
            }
            "学习辩论技巧" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "与家人进行友好辩论，提升你的逻辑思维和说服能力。"
            }
            "宇宙探索模拟" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "用天文学软件模拟太空旅行，探索太阳系和星座。"
            }
            "诗歌创作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "尝试不同的诗歌格式，如十四行诗、自由诗和俳句。"
            }
            "自制知识卡片" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "制作学习卡片复习不同主题，如历史事件或科学术语。"
            }
            "研究微生物" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用显微镜观察简单的微生物，如洋葱表皮细胞或水滴中的生物。"
            }
            "编写食谱" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "尝试创作你自己的食谱，记录下每个步骤并拍摄食物图片。"
            }
            "研究气候变化" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "学习气候变化的成因和影响，制定环保计划改变你的生活习惯。"
            }
            "学习国际象棋开局策略" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "学习不同的国际象棋开局，并用它们打败对手。"
            }
            "组装机械模型" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "购买或自制简单的机械模型，如齿轮装置，学习机械原理。"
            }
            "植物图鉴" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "研究家中植物的图鉴，学习如何辨识不同的植物种类。"
            }
            "学习速读" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "通过速读练习提高阅读速度和信息处理能力。"
            }
            "学习编结" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "学习中国传统的编结技巧，如中国结，制作精美的装饰物。"
            }
            "烘焙科学" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "学习烘焙背后的科学原理，探索不同成分如何影响最终产品。"
            }
            "历史角色扮演" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "研究一个历史人物，并在家庭中扮演他或她，分享他们的故事。"
            }
            //标签六：休闲放松
            "电影或电视剧马拉松" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "选一系列电影或剧集，享受一个完全放松的娱乐之夜。"
            }
            "听播客或有声书" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "选择不同主题的播客，学习新知识或放松心情。"
            }
            "烘焙或烹饪新菜肴" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "尝试制作复杂的蛋糕或新菜肴，享受厨房中的创作过程。"
            }
            "围绕室内植物进行园艺" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "在家布置并养护植物，营造绿意盎然的环境。"
            }
            "水疗日" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "给自己做面膜、泡脚或使用精油进行按摩，舒缓压力。"
            }
            "弹弹乐玩具制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "用简单的材料制作弹弹乐玩具，享受轻松的手工活动。"
            }
            "DIY手工香袋" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "用干花和精油制作香袋，放在衣柜里增添清香。"
            }
            "读书笔记整理" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "将你喜欢的书籍整理成笔记，并加入插图或标注。"
            }
            "微型室内花园" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "用小盆栽和多肉植物设计一个微型花园，提升空间美感。"
            }
            "温暖脚部按摩" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用按摩器或手动按摩工具，给脚部进行舒缓按摩，放松身心。"
            }
            "蜡烛制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用天然蜡和精油制作香薰蜡烛，打造温馨的氛围。"
            }
            "室内垂钓游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "用磁性垂钓玩具和水盆进行模拟钓鱼游戏，增添乐趣。"
            }
            "放松按摩" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "与伴侣交换肩颈按摩，放松紧张的肌肉。"
            }
            "香氛冥想" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "使用香薰蜡烛或精油进行冥想，提升专注力与内心平静。"
            }
            "室内帐篷营地" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "搭建帐篷，在家体验一次温馨的室内露营。"
            }
            "做香草泡浴" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "在家享受香草泡澡，舒缓肌肉并释放压力。"
            }
            "香氛笔记本" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "给你的笔记本页添加不同的香味，记录不同心情的笔记。"
            }
            "茶道体验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "学习和练习茶道，提升你的感官体验与内心平静。"
            }
            "收听自然音效" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "用音效播放大自然的声音，如海浪、鸟鸣，帮助放松。"
            }
            "冥想涂色本" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "使用涂色本来放松，帮助集中注意力和舒缓焦虑。"
            }
            "书籍讨论会" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "选择一本书并组织一个小型书籍讨论会，与家人分享观点。"
            }
            "温暖手工披肩制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "学习用针织技巧制作温暖的披肩或围巾。"
            }
            "天然护肤品制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "制作简单的自制护肤品，如蜂蜜面膜或燕麦磨砂膏。"
            }
            "感恩日记" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "每天写下一件你感恩的事情，帮助提升积极情绪。"
            }
            "泡泡浴体验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "放松在一个放满泡泡的浴缸里，点上蜡烛，享受舒适的时光。"
            }
            "精油香薰体验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "用不同的精油进行香薰疗法，帮助舒缓压力和放松情绪。"
            }
            "制作豆袋暖手袋" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用布料和大米制作一个可以加热的豆袋，用来取暖或舒缓肌肉。"
            }
            "抚慰性阅读" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "阅读一本温暖治愈的书，帮助内心得到安慰和平静。"
            }
            "手工草编" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "学习用草绳编织装饰品或篮子，体验自然手工艺。"
            }
            "熏香疗法" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "用不同的熏香棒或精油，进行一次舒缓的香薰体验。"
            }
            "编织地毯" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "用旧衣物条编织一个小型地毯，为你的房间增添特色。"
            }
            "居家露天野餐" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "在客厅铺上野餐毯，准备好食物，进行一次居家露天野餐体验。"
            }
            "泡泡冥想" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "吹泡泡并观察它们，结合深呼吸练习，达到冥想放松效果。"
            }
            "DIY梦幻灯串" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "用纸艺制作灯罩，装饰灯串，为你的空间增添梦幻氛围。"
            }
            //标签七：科技项目
            "编程或软件开发" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "完成编程项目或学习新语言，创建应用程序或网站。"
            }
            "机器人或电子工程项目" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "搭建简单的机器人或电子装置，激发你的工程热情。"
            }
            "3D打印与设计" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "设计并打印3D物品，享受数字创作带来的满足感。"
            }
            "虚拟现实体验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "使用VR设备体验新世界，探索游戏或虚拟旅行。"
            }
            "创建数字艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "在平板或电脑上创作数字插图、动画或设计项目。"
            }
            "制作迷你台风发电机" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "用磁铁和铜线制作一个简单的迷你发电机，学习电磁原理。"
            }
            "Arduino编程项目" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "尝试用Arduino控制简单的电子装置，如LED灯或小型马达。"
            }
            "旧电脑改造" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "学习如何拆解和改造旧电脑，使其功能更加多样化。"
            }
            "数字插画练习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "用平板电脑学习数字插画技巧，绘制出属于你的艺术作品。"
            }
            "家庭影院夜" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "设置一个迷你影院，播放经典电影并准备零食。"
            }
            "智能家居改造" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "研究如何优化家中的智能设备，提高生活便利性。"
            }
            "建立私人博客" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "创建并设计自己的博客平台，分享你的生活故事或见解。"
            }
            "编写一本电子书" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "用电子书格式编写一本关于你的兴趣或专业知识的书。"
            }
            "学习无人机操作" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "在家研究无人机飞行理论，为未来的操作做准备。"
            }
            "设计家用机器人" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "研究如何用简单的机器人套件制作一个家用机器人。"
            }
            "学习3D建模" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "学习使用3D建模软件，设计家具或装饰品。"
            }
            "VR绘画" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "如果有VR设备，尝试在虚拟现实中创作艺术作品。"
            }
            "编程小游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "设计并编写一个简单的文字或图形小游戏，与朋友分享。"
            }
            "创建家庭数据库" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "用软件建立一个家庭物品或收据的数据库，便于管理。"
            }
            "手机摄影挑战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "设置一个摄影主题，使用手机拍摄一系列艺术照片。"
            }
            "家用科技演示" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "演示如何优化家用智能设备，创建更智能的生活环境。"
            }
            "LED灯光项目" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "用LED灯条装饰房间，并编程控制灯光效果。"
            }
            "AI工具学习" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "学习使用AI绘画或文字生成工具，探索人工智能的创作能力。"
            }
            "网络安全课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "学习如何保护你的数据隐私，了解基本的网络安全措施。"
            }
            "虚拟博物馆参观" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "在家中在线游览全球著名的博物馆，学习艺术和历史知识。"
            }
            "家庭迷你电路实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "用电路套件设计简单的电路项目，如LED灯亮灭实验。"
            }
            "自制小风力发电机" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "用风扇、磁铁和铜线制作一个简单的风力发电机。"
            }
            "学习图像编辑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "用图像编辑软件学习基础的照片修饰和图像创意。"
            }
            "3D拼图模型" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "尝试组装一个3D拼图模型，如地球仪或城市地标。"
            }
            "自动浇水花盆" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "用塑料瓶和绳子制作一个简单的自动浇水系统。"
            }
            "家庭天气站" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "用简单的设备制作一个家庭天气站，记录温度、湿度和气压。"
            }
            "学习Python编程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "在线学习Python编程基础，编写简单的小游戏或工具。"
            }
            "设计徽标" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "用图形设计软件设计一个属于自己的徽标或品牌形象。"
            }
            "家庭投影仪DIY" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "用透镜和纸箱制作一个简单的家庭投影仪，享受大屏电影。"
            }
            "跑步或慢跑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "在公园、街道或操场进行慢跑或快跑，提升体能和心肺功能。"
            }
            "户外瑜伽" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "在草坪或沙滩上练习瑜伽，呼吸新鲜空气，感受大自然。"
            }
            "骑自行车" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "骑自行车穿越城市或乡村道路，增强下肢力量和耐力。"
            }
            "徒步旅行" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "探索自然景区或山间步道，锻炼身体同时亲近自然。"
            }
            "攀岩" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "进行自然岩壁攀爬或人工攀岩，挑战自我并提升身体协调性。"
            }
            "户外跳绳" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "利用空旷空间进行跳绳运动，锻炼心肺功能。"
            }
            "露天健身器材训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "使用公园里的健身器材进行力量或平衡训练。"
            }
            "滑板或轮滑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "尝试滑板或轮滑，既能锻炼平衡又充满乐趣。"
            }
            "足球比赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "组织朋友或家庭成员参与简单的球类运动。"
            }
            "篮球比赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "和朋友一起在球场上打篮球，锻炼你的技巧和体能。"
            }
            "野外越野跑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "选择自然地形进行越野跑步，提高耐力和挑战性。"
            }
            "飞盘游戏" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "与朋友或宠物在空旷场地玩飞盘，享受互动的乐趣。"
            }
            "野餐游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "结合户外野餐，尝试投掷游戏或简单的户外谜题。"
            }
            "真人CS或激光战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "在森林或户外竞技场模拟军事战斗，体验团队合作。"
            }
            "放风筝" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "在风大的日子放风筝，感受童趣与放松。"
            }
            "捉迷藏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "在树林或公园里玩捉迷藏，适合家庭和朋友一起参与。"
            }
            "迷宫挑战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "在农田或特殊迷宫场地里探险，找到正确路径。"
            }
            "真人版飞行棋" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "在草地上用巨型道具模拟飞行棋游戏。"
            }
            "沙滩排球" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "在沙滩上组织排球比赛，感受阳光与汗水的魅力。"
            }
            "冒险寻宝" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "在指定的区域内设计寻宝路线，结合谜题和地图寻找宝藏。"
            }
            "水上活动" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "在湖泊或河流中划船、玩水枪或体验漂流。"
            }
            "风景写生" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "带上画板和颜料，在户外绘制自然风光或街头景象。"
            }
            "沙滩雕塑" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "在沙滩上用沙子和水制作城堡或艺术作品。"
            }
            "自然摄影" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "用相机或手机记录独特的自然风景或动物瞬间。"
            }
            "户外壁画创作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "参与社区组织的墙面绘画活动，为公共场地增添色彩。"
            }
            "自然工艺品制作" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "收集树叶、松果等自然材料制作装饰品。"
            }
            "石头彩绘" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "捡拾平滑的石头，在上面进行彩绘，创作个性作品。"
            }
            "地面粉笔画" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "用彩色粉笔在地面画画，适合儿童或街头艺术爱好者。"
            }
            "竹子艺术" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "用竹子和绳子搭建小型雕塑或实用工具。"
            }
            "草编手工" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "学习用野草编织草帽或小型装饰品。"
            }
            "野外音乐会" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "携带乐器，与朋友在户外表演或练习音乐。"
            }
            "露天音乐会" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "组织或参与户外音乐会，带上乐器或音响，和朋友一起演奏。"
            }
            "街头表演" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "选择热闹的街区进行音乐或歌唱表演，与路人互动。"
            }
            "吉他弹唱" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "在沙滩、公园或草地上自弹自唱，享受音乐带来的惬意时光。"
            }
            "户外合唱" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "与朋友组成合唱团，在开放的环境中演唱喜欢的曲目。"
            }
            "非洲鼓即兴表演" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "在户外用非洲鼓进行节奏练习和即兴演奏，吸引观众参与。"
            }
            "民谣分享会" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "邀请朋友在草地上演奏民谣，分享不同的音乐风格。"
            }
            "露天录音" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "利用自然环境录制音乐或声效，比如鸟鸣、溪水声等，与音乐融合。"
            }
            "手风琴表演" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "在社区或公园用手风琴表演传统音乐，让人感受到怀旧的氛围。"
            }
            "打击乐工作坊" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "带上小型打击乐器，与参与者一起感受节奏的魅力。"
            }
            "音乐接龙游戏" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "两人或多人用乐器接龙演奏旋律，创造出即兴音乐作品。"
            }
            "观鸟" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "带上望远镜和笔记本，观察记录不同种类的鸟类。"
            }
            "植物辨识" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "学习认识各种植物和树木，包括它们的特性与用途。"
            }
            "天文观测" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "在夜间观星，寻找星座或用望远镜观测月球与行星。"
            }
            "户外科学实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "在空旷的地方做简单的化学或物理实验，比如水火箭发射。"
            }
            "参观历史遗址" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "访问当地的历史古迹或文化景点，了解它们的背景故事。"
            }
            "野外求生课程" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "学习搭帐篷、生火、取水等基本的生存技能。"
            }
            "环保教育活动" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "参加植树或垃圾清理活动，为自然环境做贡献。"
            }
            "昆虫研究" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "用网捕捉昆虫，观察其特性并分类记录。"
            }
            "拓展训练" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "参加户外拓展项目，提升团队合作和个人挑战能力。"
            }
            "考古模拟" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "在沙地挖掘埋藏物，体验考古学家的乐趣。"
            }
            "户外咖啡时光" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "带上便携咖啡壶，在阳光下享受一杯自制咖啡。"
            }
            "吊床放松" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "在两棵树间挂上吊床，静静地躺着读书或睡觉。"
            }
            "森林浴" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "漫步在森林中，放松身心，感受树木带来的宁静。"
            }
            "沙滩晒日光浴" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "在沙滩上晒太阳，补充维生素D，放松身心。"
            }
            "溪流泡脚" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa13) // 替换为实际图片资源
                activityDetailDescription.text = "在清凉的小溪中泡脚，感受自然水流的按摩。"
            }
            "观日落或日出" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa14) // 替换为实际图片资源
                activityDetailDescription.text = "寻找一个最佳观景点，欣赏日落或日出的美景。"
            }
            "野外露天电影" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa15) // 替换为实际图片资源
                activityDetailDescription.text = "在户外放映一部经典电影，与家人或朋友共享。"
            }
            "自然冥想" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa16) // 替换为实际图片资源
                activityDetailDescription.text = "在风景优美的地方进行冥想，感受与自然的连接。"
            }
            "野外写作" -> {
                activityDetailImage.setImageResource(R.drawable.wusaqi) // 替换为实际图片资源
                activityDetailDescription.text = "带上笔记本，在自然环境中写作灵感随笔。"
            }
            "垂钓" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa1) // 替换为实际图片资源
                activityDetailDescription.text = "选择安静的湖泊或河流享受钓鱼的乐趣和放松时光。"
            }
            "无人机飞行" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa2) // 替换为实际图片资源
                activityDetailDescription.text = "学习操控无人机，拍摄高质量的空中影像。"
            }
            "太阳能实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa3) // 替换为实际图片资源
                activityDetailDescription.text = "设计和测试利用太阳能的装置，比如太阳能灶。"
            }
            "遥控车竞赛" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa4) // 替换为实际图片资源
                activityDetailDescription.text = "在平坦的草地或沙地上进行遥控车比赛。"
            }
            "风力发电机模型测试" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa5) // 替换为实际图片资源
                activityDetailDescription.text = "用风能设备在户外进行能量转换实验。"
            }
            "家庭天文台搭建" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa6) // 替换为实际图片资源
                activityDetailDescription.text = "搭建便携式天文观测设备，进行夜晚观察。"
            }
            "无线电通讯实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa7) // 替换为实际图片资源
                activityDetailDescription.text = "在户外学习基础无线电通讯技能。"
            }
            "风筝装置改造" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa8) // 替换为实际图片资源
                activityDetailDescription.text = "制作或改良风筝，尝试实现独特设计的飞行模式。"
            }
            "户外机器人挑战" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa9) // 替换为实际图片资源
                activityDetailDescription.text = "带上机器人套件，在不同地形上测试功能。"
            }
            "天气监测装置" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa10) // 替换为实际图片资源
                activityDetailDescription.text = "安装和观察便携式气象监测工具，记录天气数据。"
            }
            "自然能量捕获实验" -> {
                activityDetailImage.setImageResource(R.drawable.chiikawa11) // 替换为实际图片资源
                activityDetailDescription.text = "利用自然环境收集数据，比如水能或风能实验。"
            }




            // 可以根据不同活动名称添加更多案例

        }
    }
}
package com.example.timeplanningassistant

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 启动标签选择活动
        val intent = Intent(this, TagSelectionActivity::class.java)
        startActivity(intent)
        finish() // 结束当前活动
    }
}
package com.example.timeplanningassistant

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TagSelectionActivity : AppCompatActivity() {

    private lateinit var indoorCheckBox: CheckBox
    private lateinit var outdoorCheckBox: CheckBox
    private lateinit var fitnessCheckBox: CheckBox
    private lateinit var gamesCheckBox: CheckBox
    private lateinit var artsCheckBox: CheckBox
    private lateinit var musicCheckBox: CheckBox
    private lateinit var educationCheckBox: CheckBox
    private lateinit var relaxationCheckBox: CheckBox
    private lateinit var technologyCheckBox: CheckBox
    private lateinit var individualCheckBox: CheckBox
    private lateinit var groupCheckBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tag_selection)

        // 初始化 CheckBox
        indoorCheckBox = findViewById(R.id.tagIndoor)
        outdoorCheckBox = findViewById(R.id.tagOutdoor)
        fitnessCheckBox = findViewById(R.id.tagFitness)
        gamesCheckBox = findViewById(R.id.tagGames)
        artsCheckBox = findViewById(R.id.tagArts)
        musicCheckBox = findViewById(R.id.tagMusic)
        educationCheckBox = findViewById(R.id.tagEducation)
        relaxationCheckBox = findViewById(R.id.tagRelaxation)
        technologyCheckBox = findViewById(R.id.tagTechnology)
        individualCheckBox = findViewById(R.id.tagIndividual)
        groupCheckBox = findViewById(R.id.tagGroup)

        val confirmButton: Button = findViewById(R.id.confirmButton)
        confirmButton.setOnClickListener {
            if (isSelectionValid()) {
                val selectedTags = getSelectedTags()
                // 转到活动推荐页面并传递选择的标签
                val intent = Intent(this, ActivityRecommendationActivity::class.java)
                intent.putStringArrayListExtra("selectedTags", selectedTags)
                startActivity(intent)
            }
        }

        val skipButton: Button = findViewById(R.id.skipButton)
        skipButton.setOnClickListener {
            // 跳过标签选择，随机推荐活动
            val intent = Intent(this, ActivityRecommendationActivity::class.java)
            startActivity(intent)
        }
    }

    private fun isSelectionValid(): Boolean {
        // 检查室内/室外选择
        if (!indoorCheckBox.isChecked && !outdoorCheckBox.isChecked) {
            Toast.makeText(this, "请至少选择室内或室外活动", Toast.LENGTH_SHORT).show()
            return false
        }

        // 活动类型检查
        if (!fitnessCheckBox.isChecked && !gamesCheckBox.isChecked &&
            !artsCheckBox.isChecked && !musicCheckBox.isChecked &&
            !educationCheckBox.isChecked && !relaxationCheckBox.isChecked &&
            !technologyCheckBox.isChecked) {
            Toast.makeText(this, "请至少选择一个活动类型", Toast.LENGTH_SHORT).show()
            return false
        }

        // 活动人数检查
        if (!individualCheckBox.isChecked && !groupCheckBox.isChecked) {
            Toast.makeText(this, "请至少选择个人或多人活动", Toast.LENGTH_SHORT).show()
            return false
        }

        return true // 所有检查通过
    }

    private fun getSelectedTags(): ArrayList<String> {
        val tags = ArrayList<String>()
        if (indoorCheckBox.isChecked) tags.add("室内")
        if (outdoorCheckBox.isChecked) tags.add("室外")
        if (fitnessCheckBox.isChecked) tags.add("运动健身")
        if (gamesCheckBox.isChecked) tags.add("休闲游戏")
        if (artsCheckBox.isChecked) tags.add("创意艺术")
        if (musicCheckBox.isChecked) tags.add("音乐表演")
        if (educationCheckBox.isChecked) tags.add("学习教育")
        if (relaxationCheckBox.isChecked) tags.add("休闲放松")
        if (technologyCheckBox.isChecked) tags.add("科技项目")
        if (individualCheckBox.isChecked) tags.add("个人")
        if (groupCheckBox.isChecked) tags.add("多人")

        return tags
    }
}
